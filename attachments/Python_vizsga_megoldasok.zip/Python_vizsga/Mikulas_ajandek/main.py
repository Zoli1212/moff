class Ajandek:
    def __init__(self, nev, suly, min_eletkor, tipus):
        self.nev = nev
        self.suly = suly
        self.min_eletkor = min_eletkor
        self.tipus = tipus

    def __str__(self):
        return f"Ajándék név: {self.nev}, súly: {self.suly} kg, minimum életkor: {self.min_eletkor}, típusa: {self.tipus}"


class Gyerek:
    def __init__(self, nev, eletkor, viselkedes):
        self.nev = nev
        self.eletkor = eletkor
        self.viselkedes = viselkedes.lower()

    def megerdemli(self):
        return self.viselkedes == "jó"


class Puttony:
    def __init__(self, max_suly):
        self.max_suly = max_suly
        self.ajandekok = []

    def add_ajandek(self, ajandek):
        if self.osszsuly() + ajandek.suly > self.max_suly:
            raise ValueError("Az ajándék túllépi a megengedett súlyt.")
        self.ajandekok.append(ajandek)

    def osszsuly(self):
        ossz = 0
        for ajci in self.ajandekok:
            ossz += ajci.suly
        return ossz

    def listazas(self):
        if not self.ajandekok:
            return "A puttony üres."
        return "\n".join(str(ajci) for ajci in self.ajandekok)

    def elvesszuk_ajandek(self, eletkor):
        for i, ajci in enumerate(self.ajandekok):
            if ajci.min_eletkor <= eletkor:
                return self.ajandekok.pop(i)
        return None


class Mikulas:
    def __init__(self, nev, puttony):
        self.nev = nev
        self.puttony = puttony

    def ajandekoz(self, gyerek):
        if gyerek.megerdemli():
            ajci = self.puttony.elvesszuk_ajandek(gyerek.eletkor)
            if ajci:
                return f"{gyerek.nev} megkapta az ajándékot: {ajci.nev}."
            else:
                return f"{gyerek.nev}-nak/-nek nincs megfelelő ajándék."
        else:
            return f"{gyerek.nev} virgácsot kapott."


def main():
    puttony = Puttony(10)
    puttony.add_ajandek(Ajandek("Plüssmackó", 2.5, 1, "játék"))
    puttony.add_ajandek(Ajandek("Csoki", 1.0, 0, "édesség"))
    puttony.add_ajandek(Ajandek("Ifjúsági regény", 1.5, 12, "könyv"))
    puttony.add_ajandek(Ajandek("Iphone 23 Pro Maximus", 1.5, 18, "telefon"))

    gyerekek = [
        Gyerek("István", 5, "jó"),
        Gyerek("Viktor", 10, "rossz"),
        Gyerek("Mónika", 13, "jó"),
        Gyerek("Péter", 12, "jó"),
        Gyerek("Zoltán", 33, "jó"),
        Gyerek("Kata", 11, "jó"),
    ]

    mikulas = Mikulas("Télapó", puttony)

    for g in gyerekek:
        print(mikulas.ajandekoz(g))


if __name__ == "__main__":
    main()
