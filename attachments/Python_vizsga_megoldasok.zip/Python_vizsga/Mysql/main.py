Listázd ki az összes könyv címét!
SELECT title FROM books;

Mely könyveket írta J.K. Rowling?
SELECT b.title FROM books b JOIN authors a ON b.author_id = a.author_id WHERE a.name = 'J.K. Rowling';

Listázd ki azokat a könyveket, amiket 1945 előtt adtak ki!
SELECT title FROM books WHERE publication_year < 1945;

Melyik könyvet nem adták még vissza?
SELECT b.title FROM borrows br JOIN books b ON br.book_id = b.book_id WHERE br.return_date IS NULL;

Hány könyvet írt George Orwell?
SELECT COUNT(*) AS orwell_books FROM books b JOIN authors a ON b.author_id = a.author_id WHERE a.name = 'George Orwell';

Listázd ki az összes szerző nevét, születési év szerint növekvő sorrendben!
SELECT name FROM authors ORDER BY birth_year ASC;

Hány könyvet kölcsönöztek ki összesen?
SELECT COUNT(*) AS total_borrows FROM borrows;

Milyen című könyveket kölcsönöztek 2025. május 5-én?
SELECT b.title FROM borrows br JOIN books b ON br.book_id = b.book_id WHERE br.borrow_date = '2025-05-05';

Listázd ki az összes kölcsönzést, ahol a visszahozatal dátuma korábbi, mint 2025-05-12!
SELECT br.borrow_id, b.title, br.return_date FROM borrows br JOIN books b ON br.book_id = b.book_id WHERE br.return_date < '2025-05-12';

Listázd ki azokat a szerzőket, akiknek legalább egy könyvét kikölcsönözték!
SELECT a.name FROM authors a, books b, borrows br WHERE a.author_id = b.author_id AND b.book_id = br.book_id GROUP BY a.name;