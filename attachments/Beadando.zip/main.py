import requests
import datetime
import os
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker

Base = declarative_base()


class WeatherHistory(Base):
    __tablename__ = "weather_history"
    id = Column(Integer, primary_key=True)
    city = Column(String)
    description = Column(String)
    temperature = Column(Float)
    humidity = Column(Integer)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
db_path = os.path.join(BASE_DIR, "weather.db")
engine = create_engine(f"sqlite:///{db_path}")
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
session = Session()

API_KEY = "e3d415cf758d46a3db24c90ad80aa5f9"
BASE_URL = "http://api.openweathermap.org/data/2.5/weather?"
LOG_FILE = "weather_log.txt"


def get_weather(city_name):
    params = {"q": city_name, "appid": API_KEY, "units": "metric"}

    response = requests.get(BASE_URL, params=params)
    if response.status_code == 200:
        return response.json()
    else:
        print(
            f"Hiba: Az időjárási adatok lekérése sikertelen volt. Státusz kód: {response.status_code}"
        )
        return None


def save_to_db(city, description, temp, humidity):
    record = WeatherHistory(
        city=city, description=description, temperature=temp, humidity=humidity
    )
    session.add(record)
    session.commit()


def save_to_log(city, description, temp, humidity):
    with open(LOG_FILE, "a") as file:
        file.write(
            f"{datetime.datetime.now()} - {city} - {description} - {temp}°C - {humidity}% humidity\n"
        )


def display_weather(data):
    city = data["name"]
    description = data["weather"][0]["description"].capitalize()
    temp = data["main"]["temp"]
    humidity = data["main"]["humidity"]

    print(f"\nJelenlegi időjárás itt: {city}:")
    print(f"Leírás: {description}")
    print(f"Hőmérséklet: {temp}°C")
    print(f"Páratartalom: {humidity}%")

    save_to_db(city, description, temp, humidity)
    save_to_log(city, description, temp, humidity)


def search_history():
    print("\n--- Weather History ---")
    records = (
        session.query(WeatherHistory).order_by(WeatherHistory.timestamp.desc()).all()
    )
    for record in records:
        print(
            f"{record.timestamp} | {record.city} | {record.description} | {record.temperature}°C | {record.humidity}%"
        )


def main():
    while True:
        print("\n=== Időjárásjelentés ===")
        print("1. Időjárás megjelenítése város alapján")
        print("2. Időjárási előzmények")
        print("3. Kilépés")

        choice = input(
            "Mit szeretne csinálni? (Írja be az önnek megfelelő számot: 1/2/3): "
        )

        if choice == "1":
            city = input("Írja be a város nevét (Pl.: Debrecen): ")
            data = get_weather(city)
            if data:
                display_weather(data)
        elif choice == "2":
            search_history()
        elif choice == "3":
            print("Viszlát!")
            break
        else:
            print("Érvénytelen választás. Próbálja újra!")


if __name__ == "__main__":
    main()
