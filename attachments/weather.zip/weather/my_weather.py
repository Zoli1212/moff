import os
import requests
from flask import Flask, request, redirect, render_template
from flask_sqlalchemy import SQLAlchemy
from dotenv import load_dotenv

# Környezeti változók betöltése
load_dotenv()
API_KEY = os.getenv("API_KEY")

# Flask konfiguráció
app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///weather.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)


# Adatbázis modell
class Weather(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    city = db.Column(db.String(50), nullable=False)
    temperature = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(100), nullable=False)


# API lekérő osztály (OOP)
class WeatherService:
    def __init__(self, api_key):
        self.api_key = api_key

    def get_weather(self, city):
        url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={self.api_key}&units=metric&lang=hu"
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            return {
                "city": city,
                "temperature": data["main"]["temp"],
                "description": data["weather"][0]["description"],
            }
        else:
            raise Exception(f"API hiba: {response.status_code}, {response.text}")


# Példányosítás
weather_service = WeatherService(API_KEY)


@app.route("/")
def index():
    weather_data = Weather.query.all()
    return render_template("index.html", weather_data=weather_data)


@app.route("/get_weather", methods=["POST"])
def get_weather():
    city = request.form["city"]
    try:
        data = weather_service.get_weather(city)
        weather = Weather(
            city=data["city"],
            temperature=data["temperature"],
            description=data["description"],
        )
        db.session.add(weather)
        db.session.commit()
    except Exception as e:
        return f"Hiba: {e}"
    return redirect("/")


@app.route("/delete", methods=["POST"])
def delete_weather():
    city = request.form["city"]
    Weather.query.filter_by(city=city).delete()
    db.session.commit()
    return redirect("/")


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
